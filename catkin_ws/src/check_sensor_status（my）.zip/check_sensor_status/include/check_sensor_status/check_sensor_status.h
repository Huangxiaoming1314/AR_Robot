#ifndef _CHECK_SENSOR_STATUS_
#define _CHECK_SENSOR_STATUS_

#define  POWER_OFF  0
#define  POWER_ON   1

#endif
